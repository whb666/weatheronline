package com.example.coolweather.gson;

/**
 * Created by len_titude on 2017/5/19.
 */

public class Alarms {
    public String level;
    public String stat;
    public String title;
    public String txt;
    public String type;
}
