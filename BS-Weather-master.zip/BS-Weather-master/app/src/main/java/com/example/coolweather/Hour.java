package com.example.coolweather;

/**
 * Created by len_titude on 2017/5/13.
 */

public class Hour {

    private String degree;

    private String time;

    private String text;

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
